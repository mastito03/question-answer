
@extends('main')

@section('content')

<div class="row">
  <div class="col-sm-12"></div>
</div>
@stop
