
<footer>
  <div class="row">
    <div class="col-sm-12">
      <hr/>
      <div class="row">
        <div class="col-sm-5">
          <p>© Copyright treeva digital studio</p>
        </div>
        <div class="col-sm-7">
          <ul class="list-inline pull-right">
            <li><a href="#">Link</a></li>
            <li><a href="#">Link</a></li>
            <li><a href="#">Link</a></li>
            <li><a href="#">Link</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>