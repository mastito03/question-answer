<?php

namespace App;

use Cartalyst\Sentinel\Roles\EloquentRole as Model;

class Role extends Model
{
    //
}
